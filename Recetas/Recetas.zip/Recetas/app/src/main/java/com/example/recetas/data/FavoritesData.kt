package com.example.recetas.data

import androidx.compose.runtime.mutableStateListOf

object FavoritesData {
    val favorites = mutableStateListOf<String>()
}